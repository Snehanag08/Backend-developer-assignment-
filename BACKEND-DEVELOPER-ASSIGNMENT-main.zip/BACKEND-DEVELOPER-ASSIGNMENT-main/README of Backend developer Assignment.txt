Here is a detailed README.md file for my assignment submission portal project. This includes an overview, installation instructions, setup details, and descriptions of each API endpoint.


---

Assignment Submission Portal

This project is a backend system for an assignment submission portal. It allows users to register, log in, and upload assignments, while admins can view, accept, or reject assignments tagged to them. The backend is built using Node.js, Express, and MongoDB.

Features

User:

Register and log in.

Upload assignments with a specified admin.

Fetch a list of available admins to assign tasks.


Admin:

Register and log in.

View assignments tagged to them.

Accept or reject assignments.




---

Technologies Used

Node.js and Express for the backend.

MongoDB for database storage.

Mongoose for modeling MongoDB data.

JWT (JSON Web Tokens) for user authentication.



---

Getting Started

Prerequisites

Node.js and npm should be installed on your machine.

MongoDB server running locally or a MongoDB URI if using MongoDB Atlas.


Installation

1. Clone the repository:

git clone https://github.com/your-username/assignment-submission-portal.git
cd assignment-submission-portal


2. Install dependencies:

npm install


3. Set up environment variables:

Create a .env file in the root directory with the following content:

JWT_SECRET=your_jwt_secret
MONGO_URI=your_mongodb_connection_uri
PORT=3000



4. Start the server:

npm start

The server will be running at http://localhost:3000.




---

API Endpoints

User Endpoints

1. Register a new user - POST /register

Registers a new user account.

Request Body:

{
  "username": "user123",
  "password": "password123"
}



2. User login - POST /login

Logs in a user and provides a JWT token.

Request Body:

{
  "username": "user123",
  "password": "password123"
}



3. Upload an assignment - POST /upload

Uploads an assignment for a specific admin.

Request Body:

{
  "task": "Complete Backend Assignment",
  "adminId": "admin-object-id"
}

Headers:

Authorization: Bearer <JWT_TOKEN>




4. Fetch all admins - GET /admins

Retrieves a list of all available admins.




Admin Endpoints

1. Register a new admin - POST /register

Registers a new admin account.

Request Body:

{
  "username": "admin123",
  "password": "adminpass"
}



2. Admin login - POST /login

Logs in an admin and provides a JWT token.

Request Body:

{
  "username": "admin123",
  "password": "adminpass"
}



3. View assignments tagged to the admin - GET /assignments

Retrieves all assignments submitted to the logged-in admin.

Headers:

Authorization: Bearer <JWT_TOKEN>




4. Accept an assignment - POST /assignments/:id/accept

Marks a specified assignment as accepted.

Headers:

Authorization: Bearer <JWT_TOKEN>




5. Reject an assignment - POST /assignments/:id/reject

Marks a specified assignment as rejected.

Headers:

Authorization: Bearer <JWT_TOKEN>






---

Project Structure

assignment-submission-portal/
├── controllers/
│   ├── authController.js      # Handles authentication logic for users and admins
│   ├── userController.js      # Manages user-specific actions
│   └── adminController.js     # Manages admin-specific actions
├── models/
│   ├── User.js                # Defines the User model schema
│   ├── Admin.js               # Defines the Admin model schema
│   └── Assignment.js          # Defines the Assignment model schema
├── routes/
│   ├── userRoutes.js          # Routes for user actions
│   └── adminRoutes.js         # Routes for admin actions
├── middlewares/
│   ├── authMiddleware.js      # Middleware to handle JWT authentication
│   └── validationMiddleware.js # Middleware to handle input validation
├── config/
│   └── db.js                  # MongoDB connection configuration
├── utils/
│   └── errorHandler.js        # Handles error responses
├── app.js                     # Main app setup
├── server.js                  # Entry point to start the server
└── README.md                  # Project documentation


---

Middleware

authMiddleware.js: Checks if the user or admin is authenticated using JWT.

validationMiddleware.js: Validates request data for endpoints.



---

Database Models

User: Stores user information, such as username and password.

Admin: Stores admin information, including username and password.

Assignment: Stores assignment data, including task details, associated admin, status, and timestamps.



---

Error Handling

The errorHandler.js utility provides consistent error responses for invalid inputs or unauthorized actions.


---

License

This project is licensed under the MIT License. See the LICENSE file for more information.


---

Contributing

If you’d like to contribute, please fork the repository and make a pull request with your proposed changes.


